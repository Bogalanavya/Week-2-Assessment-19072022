val strToFormat = "https://www.google.com"
val reversedAndToUpperCase = strToFormat.reverse.toUpperCase()
println(s"$strToFormat reversed and then to upper case = $reversedAndToUpperCase")
